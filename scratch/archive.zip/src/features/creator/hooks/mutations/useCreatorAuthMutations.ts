import { useMutation } from '@tanstack/react-query';
import creatorApi from '@/features/creator/api';

export function useCreatorVerifyEmailMutation() {
  return useMutation({
    mutationFn: (args: { token: string; email: string }) =>
      creatorApi.verifyEmail(args.token, args.email),
  });
}

export function useCreatorResendVerificationMutation() {
  return useMutation({
    mutationFn: (email: string) => creatorApi.resendVerification(email),
  });
}

export function useCreatorRegisterMutation() {
  return useMutation({
    mutationFn: (args: {
      token: string;
      firstName: string;
      lastName: string;
      email: string;
      mpesaNumber: string;
      whatsappNumber: string;
      password: string;
      confirmPassword: string;
      referralCode?: string;
    }) => creatorApi.register(args),
  });
}

export function useCreatorLogoutMutation() {
  return useMutation({
    mutationFn: () => creatorApi.logout(),
  });
}


