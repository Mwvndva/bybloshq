import { getRedisClient } from '../config/redis.js';
import logger from './logger.js';

class CacheService {
    constructor() {
        this.redis = getRedisClient();
        this.defaultTTL = 300; // 5 minutes default
    }

    /**
     * Get value from cache
     * @param {string} key 
     * @returns {Promise<any>}
     */
    async get(key) {
        try {
            if (!this.redis) return null;

            const data = await this.redis.get(key);
            if (data) {
                return JSON.parse(data);
            }
            return null;
        } catch (error) {
            logger.error(`Cache Get Error (${key}):`, error);
            return null;
        }
    }

    /**
     * Set value in cache
     * @param {string} key 
     * @param {any} value 
     * @param {number} ttlSeconds 
     */
    async set(key, value, ttlSeconds = this.defaultTTL) {
        try {
            if (!this.redis) return false;

            const stringValue = JSON.stringify(value);
            await this.redis.set(key, stringValue, 'EX', ttlSeconds);
            return true;
        } catch (error) {
            logger.error(`Cache Set Error (${key}):`, error);
            return false;
        }
    }

    /**
     * Delete value from cache
     * @param {string} key 
     */
    async del(key) {
        try {
            if (!this.redis) return false;
            await this.redis.del(key);
            return true;
        } catch (error) {
            logger.error(`Cache Del Error (${key}):`, error);
            return false;
        }
    }

    /**
     * Delete value from cache (alias)
     * @param {string} key 
     */
    async delete(key) {
        return await this.del(key);
    }

    /**
     * Clear cache with pattern
     * @param {string} pattern e.g. "products:*"
     */
    async clearPattern(pattern) {
        try {
            if (!this.redis) return false;
            let cursor = '0';
            const allKeys = [];
            do {
                const [nextCursor, keys] = await this.redis.scan(cursor, 'MATCH', pattern, 'COUNT', 1000);
                cursor = nextCursor;
                if (keys && keys.length > 0) allKeys.push(...keys);
            } while (cursor !== '0');

            if (allKeys.length > 0) {
                // Delete in chunks of 500
                for (let i = 0; i < allKeys.length; i += 500) {
                    const chunk = allKeys.slice(i, i + 500);
                    await this.redis.del(chunk);
                }
            }
            return true;
        } catch (error) {
            logger.error(`Cache Clear Pattern Error (${pattern}):`, error);
            return false;
        }
    }
}

export default new CacheService();

