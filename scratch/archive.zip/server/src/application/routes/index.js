/**
 * Central route aggregator — server/src/routes/index.js
 * All API routes are mounted here and exposed as a single Express Router.
 * This is then mounted at /api in server/src/index.js.
 */
import express from 'express';

import sellerRoutes from './seller.routes.js';
import buyerRoutes from './buyer.routes.js';
import publicRoutes from './public.routes.js';
import healthRoutes from './health.routes.js';
import paymentRoutes from './payment.routes.js';
import adminRoutes from './admin.routes.js';
import refundRoutes from './refund.routes.js';
import callbackRoutes from './callback.routes.js';
import webhookRoutes from './webhook.routes.js';
import orderRoutes from './order.routes.js';
import refreshTokenRoutes from './refreshToken.routes.js';
import accountRoutes from './account.routes.js';
import wishlistRoutes from './wishlist.routes.js';
import marketingRoutes from './marketing.routes.js';
import logisticsRoutes from './logistics.routes.js';
import trackingRoutes from './tracking.routes.js';
import creatorRoutes from './creator.routes.js';
import locationRoutes from './location.routes.js';
import notificationRoutes from './notification.routes.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

// ─── Public / Unauthenticated Routes ────────────────────────────────────────
router.use('/sellers', sellerRoutes);
router.use('/buyers', buyerRoutes);
router.use('/public', publicRoutes);
router.use('/health', healthRoutes);
router.use('/payments', paymentRoutes);
router.use('/admin/marketing', marketingRoutes);
router.use('/admin', adminRoutes);
router.use('/refunds', refundRoutes);
router.use('/auth', refreshTokenRoutes);
router.use('/auth', accountRoutes);
router.use('/callbacks', callbackRoutes);
router.use('/webhooks', webhookRoutes);
router.use('/orders', orderRoutes);
router.use('/wishlist', wishlistRoutes);
router.use('/logistics', logisticsRoutes);
router.use('/tracking', trackingRoutes);
router.use('/creators', creatorRoutes);
router.use('/locations', locationRoutes);
router.use('/notifications', notificationRoutes);

export default router;
