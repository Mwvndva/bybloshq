import ProductService from './product.service.js';
import logger from '../../../shared/utils/logger.js';
import ImageService from '../../../infrastructure/storage/image.service.js';
import { sanitizeProduct } from '../../../shared/utils/sanitize.js';

// Upload digital file handler — file is already uploaded to Cloudinary by cloudinaryDigitalUpload middleware
export const uploadDigitalFile = async (req, res) => {
  try {
    if (!req.cloudinaryFile) {
      return res.status(400).json({ status: 'error', message: 'No file uploaded' });
    }
    res.status(200).json({
      status: 'success',
      data: {
        // public_id is stored in products.digital_file_path and used to generate signed download URLs
        filePath: req.cloudinaryFile.public_id,
        fileName: req.cloudinaryFile.original_filename,
        size: req.cloudinaryFile.bytes
      }
    });
  } catch (error) {
    logger.error('Error uploading digital file:', error);
    res.status(500).json({ status: 'error', message: 'Failed to upload file' });
  }
};

export const createProduct = async (req, res) => {
  try {
    if (!(await req.user.can('manage-products'))) {
      return res.status(403).json({
        status: 'error',
        message: 'You do not have permission to create products'
      });
    }

    // Email verification guard for sellers
    if (!req.user.is_verified) {
      return res.status(403).json({
        status: 'error',
        message: 'Please verify your email before listing products.',
        code: 'EMAIL_NOT_VERIFIED'
      });
    }

    const sellerId = req.user.sellerId;

    // Convert base64 image to file if present
    if (req.body.image_url && ImageService.isBase64Image(req.body.image_url)) {
      req.body.image_url = await ImageService.base64ToFile(req.body.image_url, 'product');
    }

    // Convert extra images if present
    if (req.body.images && Array.isArray(req.body.images)) {
      req.body.images = await ImageService.convertMultiple(req.body.images, 'product_extra');
    }

    const product = await ProductService.createProduct(sellerId, req.body);

    res.status(201).json({
      status: 'success',
      data: { product: sanitizeProduct(product) }
    });
  } catch (error) {
    if (error.isOperational) {
      logger.warn(`Product creation validation failed: ${error.message}`);
      return res.status(error.statusCode || 400).json({
        status: 'error',
        message: error.message
      });
    }
    logger.error('Error creating product:', error);
    const status = error.message.includes('required') || error.message.includes('Invalid') ? 400 : 500;
    res.status(status).json({
      status: 'error',
      message: error.message
    });
  }
};

export const getSellerProducts = async (req, res) => {
  try {
    const sellerId = req.user.sellerId;
    const products = await ProductService.getSellerProducts(sellerId);

    const sanitized = products.map(p => sanitizeProduct(p));

    res.status(200).json({
      status: 'success',
      results: sanitized.length,
      data: { products: sanitized }
    });
  } catch (error) {
    logger.error('Error fetching products:', error);
    res.status(500).json({ status: 'error', message: 'Failed to fetch products' });
  }
};

export const getProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const sellerId = req.user.sellerId;

    const product = await ProductService.getProduct(id, sellerId);

    res.status(200).json({
      status: 'success',
      data: { product: sanitizeProduct(product) }
    });
  } catch (error) {
    logger.error('Error fetching product:', error);
    const status = error.message.includes('not found') ? 404 : 500;
    res.status(status).json({ status: 'error', message: error.message });
  }
};

export const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;

    // Fetch product first to check ownership
    const product = await ProductService.getProduct(id, null);

    if (!(await req.user.can('manage-products', product, 'product', 'manage'))) {
      return res.status(403).json({
        status: 'error',
        message: 'You do not have permission to update this product'
      });
    }

    // Convert base64 image to file if present
    if (req.body.image_url && ImageService.isBase64Image(req.body.image_url)) {
      req.body.image_url = await ImageService.base64ToFile(req.body.image_url, 'product');
    }

    // Convert extra images if present
    if (req.body.images && Array.isArray(req.body.images)) {
      req.body.images = await ImageService.convertMultiple(req.body.images, 'product_extra');
    }

    const updatedProduct = await ProductService.updateProduct(req.user.sellerId, id, req.body);

    res.status(200).json({
      status: 'success',
      data: { product: sanitizeProduct(updatedProduct) }
    });
  } catch (error) {
    if (error.isOperational) {
      logger.warn(`Product update validation failed: ${error.message}`);
      return res.status(error.statusCode || 400).json({
        status: 'error',
        message: error.message
      });
    }
    logger.error('Error updating product:', error);
    let status = 500;
    if (error.message.includes('not found')) status = 404;
    res.status(status).json({ status: 'error', message: error.message });
  }
};

export const updateInventory = async (req, res) => {
  try {
    const { id } = req.params;
    const { track_inventory, quantity, low_stock_threshold } = req.body;

    // Fetch product first to check ownership
    const product = await ProductService.getProduct(id, null);

    if (!(await req.user.can('manage-products', product, 'product', 'manage'))) {
      return res.status(403).json({
        status: 'error',
        message: 'You do not have permission to update this product'
      });
    }

    // Validate inventory data
    if (track_inventory && quantity !== null && quantity < 0) {
      return res.status(400).json({
        status: 'error',
        message: 'Quantity cannot be negative'
      });
    }

    const updatedProduct = await ProductService.updateInventory(id, {
      track_inventory,
      quantity: track_inventory ? quantity : null,
      low_stock_threshold: track_inventory ? low_stock_threshold : null
    });

    res.status(200).json({
      status: 'success',
      data: { product: sanitizeProduct(updatedProduct) }
    });
  } catch (error) {
    logger.error('Error updating inventory:', error);
    let status = 500;
    if (error.message.includes('not found')) status = 404;
    res.status(status).json({ status: 'error', message: error.message });
  }
};

export const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;

    // Fetch product first for policy check
    const product = await ProductService.getProduct(id, null);

    if (!(await req.user.can('manage-products', product, 'product', 'manage'))) {
      return res.status(403).json({
        status: 'error',
        message: 'You do not have permission to delete this product'
      });
    }

    await ProductService.deleteProduct(req.user.sellerId, id);

    res.status(204).json({ status: 'success', data: null });
  } catch (error) {
    logger.error('Error deleting product:', error);
    const status = error.message.includes('not found') ? 404 : 500;
    res.status(status).json({ status: 'error', message: error.message });
  }
};


