import { pool } from '../../../infrastructure/database/database.js';
import bcrypt from 'bcrypt';

class User {
    /**
     * Find user by email
     * @param {string} email 
     * @returns {Promise<Object|null>}
     */
    static async findByEmail(email) {
        if (!email) return null;
        // PERF-06: select only needed columns
        const query = 'SELECT id, email, password_hash, role, is_verified, is_active FROM users WHERE LOWER(email) = $1';
        const result = await pool.query(query, [email.toLowerCase()]);
        return result.rows[0] || null;
    }

    /**
     * Find user by ID
     * @param {number} id 
     * @returns {Promise<Object|null>}
     */
    static async findById(id) {
        if (!id) return null;
        const query = 'SELECT id, email, role, is_verified, is_active FROM users WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Create a new user
     * @param {Object} userData 
     * @returns {Promise<Object>}
     */
    static async create({ email, password, role, is_verified = false }, externalClient = null) {
        const hashedPassword = await bcrypt.hash(password, 12);
        const client = externalClient || await pool.connect();
        const shouldManageTransaction = !externalClient;
        try {
            if (shouldManageTransaction) await client.query('BEGIN');

            const userQuery = `
                INSERT INTO users (email, password_hash, role, is_verified, created_at, updated_at)
                VALUES ($1, $2, $3, $4, NOW(), NOW())
                RETURNING id, email, role, is_verified, created_at, updated_at
            `;

            const userResult = await client.query(userQuery, [
                email.toLowerCase(),
                hashedPassword,
                role,
                is_verified
            ]);

            const newUser = userResult.rows[0];

            // Assign role in user_roles table
            if (role) {
                const roleResult = await client.query('SELECT id FROM roles WHERE slug = $1', [role]);
                if (roleResult.rows[0]) {
                    const roleId = roleResult.rows[0].id;
                    await client.query(
                        'INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                        [newUser.id, roleId]
                    );
                }
            }

            if (shouldManageTransaction) await client.query('COMMIT');
            return newUser;
        } catch (error) {
            if (shouldManageTransaction) await client.query('ROLLBACK');
            throw error;
        } finally {
            if (shouldManageTransaction) client.release();
        }
    }

    /**
     * Verify password
     * @param {string} candidatePassword 
     * @param {string} hashedPassword 
     * @returns {Promise<boolean>}
     */
    static async verifyPassword(candidatePassword, hashedPassword) {
        return await bcrypt.compare(candidatePassword, hashedPassword);
    }

    /**
     * Update last login timestamp
     * @param {number} userId 
     */
    static async updateLastLogin(userId) {
        const query = 'UPDATE users SET last_login = NOW() WHERE id = $1';
        await pool.query(query, [userId]);
    }

    /**
     * Set password reset token
     * @param {string} email 
     * @param {string} token 
     * @param {Date} expires 
     */
    static async setPasswordResetToken(email, token, expires) {
        const query = `
      UPDATE users
      SET reset_password_token = $1, reset_password_expires = $2, updated_at = NOW()
      WHERE LOWER(email) = $3
      RETURNING id, email, role
    `;
        const result = await pool.query(query, [token, expires, email.toLowerCase()]);
        return result.rows[0] || null;
    }

    /**
     * Verify password reset token
     * @param {string} email 
     * @param {string} token 
     * @returns {Promise<boolean>}
     */
    static async verifyPasswordResetToken(email, token) {
        const query = `
      SELECT * FROM users
      WHERE LOWER(email) = $1
      AND reset_password_token = $2
      AND reset_password_expires > NOW()
    `;
        const result = await pool.query(query, [email.toLowerCase(), token]);
        return result.rows.length > 0;
    }

    /**
     * Store a hashed email verification token for a user
     * @param {string} email
     * @param {string} hashedToken - SHA-256 hash of the raw token
     * @param {Date} expires - expiry timestamp
     */
    static async setEmailVerificationToken(email, hashedToken, expires) {
        const query = `
      UPDATE users
      SET email_verification_token = $1,
          email_verification_expires = $2,
          updated_at = NOW()
      WHERE email = $3
      RETURNING id, email
    `
        const result = await pool.query(query, [hashedToken, expires, email.toLowerCase()])
        return result.rows[0] || null
    }

    /**
     * Verify an email verification token. Returns the user if valid, null if not.
     * @param {string} email
     * @param {string} hashedToken - SHA-256 hash of the raw token
     * @returns {Promise<Object|null>}
     */
    static async verifyEmailToken(email, hashedToken) {
        const query = `
      SELECT id, email, role, is_verified
      FROM users
      WHERE LOWER(email) = $1
        AND email_verification_token = $2
        AND email_verification_expires > NOW()
    `
        const result = await pool.query(query, [email.toLowerCase(), hashedToken])
        return result.rows[0] || null
    }

    /**
     * Mark user email as verified and clear the verification token (single-use)
     * @param {string} email
     */
    static async markEmailVerified(email) {
        const query = `
      UPDATE users
      SET is_verified = true,
          email_verification_token = NULL,
          email_verification_expires = NULL,
          updated_at = NOW()
      WHERE LOWER(email) = $1
      RETURNING id, email, role, is_verified
    `
        const result = await pool.query(query, [email.toLowerCase()])
        return result.rows[0] || null
    }

    /**
     * Update password for a logged in user
     * @param {number} userId 
     * @param {string} newPassword 
     */
    static async updatePassword(userId, newPassword) {
        const hashedPassword = await bcrypt.hash(newPassword, 12);

        const query = `
      UPDATE users 
      SET password_hash = $1, 
          password_changed_at = NOW(),
          updated_at = NOW()
      WHERE id = $2
      RETURNING id, email, role
    `;

        const result = await pool.query(query, [hashedPassword, userId]);
        return result.rows[0] || null;
    }

    /**
     * Reset password
     * @param {string} email 
     * @param {string} newPassword 
     */
    static async resetPassword(email, newPassword) {
        const hashedPassword = await bcrypt.hash(newPassword, 12);

        const query = `
      UPDATE users 
      SET password_hash = $1,
          reset_password_token = NULL,
          reset_password_expires = NULL,
          password_changed_at = NOW(),
          updated_at = NOW()
      WHERE LOWER(email) = $2
      RETURNING id, email, role
    `;

        const result = await pool.query(query, [hashedPassword, email.toLowerCase()]);
        return result.rows[0] || null;
    }
}

export default User;

